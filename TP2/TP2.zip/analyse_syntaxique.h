void analyser (char *fichier, int *resultat);
void counter_para(int *number);
void rec_ea(int *resultat);
